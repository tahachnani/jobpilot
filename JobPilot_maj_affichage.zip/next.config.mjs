/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    // React-PDF embarque son propre moteur de composition et ses polices :
    // passé au bundler de Next, il se casse. Il doit rester un paquet Node
    // externe.
    serverComponentsExternalPackages: ["@react-pdf/renderer"],

    // Externaliser ne suffit pas. Les polices standard du PDF sont chargées
    // par un `require` calculé au moment du rendu, que l'analyse statique de
    // Vercel ne voit pas : les fichiers restaient hors de la fonction
    // serverless, d'où « Cannot find module ... standard-fonts/Helvetica.cjs »
    // à la première composition. On les inclut explicitement.
    outputFileTracingIncludes: {
      "/**": [
        "./node_modules/pdfkit/**/*",
        "./node_modules/@react-pdf/**/*",
        "./node_modules/fontkit/**/*",
      ],
    },

    serverActions: {
      // Une action serveur accepte 1 Mo par défaut : trop peu pour un PDF
      // d'offre un peu illustré.
      bodySizeLimit: "6mb",
    },
  },
};
export default nextConfig;
