/** @type {import('next').NextConfig} */
const nextConfig = {
  // React-PDF embarque ses propres polices et un moteur de composition : passé
  // au bundler de Next il se casse. Il doit rester un paquet Node externe.
  experimental: {
    serverComponentsExternalPackages: ["@react-pdf/renderer"],
    serverActions: {
      // Une action serveur accepte 1 Mo par défaut : trop peu pour un PDF
      // d'offre un peu illustré. Au-delà, Next renvoie une erreur muette.
      bodySizeLimit: "6mb",
    },
  },
};
export default nextConfig;
